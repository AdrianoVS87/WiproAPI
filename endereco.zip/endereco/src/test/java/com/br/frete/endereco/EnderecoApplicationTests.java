package com.br.frete.endereco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnderecoApplicationTests {

	@Test
	void contextLoads() {
	}

}
